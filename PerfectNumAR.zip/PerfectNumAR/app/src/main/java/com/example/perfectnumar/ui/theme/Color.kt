package com.example.perfectnumar.ui.theme

import android.graphics.Color

object AppColors {
    val Purple80 = Color.parseColor("#FFD0BCFF")
    val PurpleGrey80 = Color.parseColor("#FFCCC2DC")
    val Pink80 = Color.parseColor("#FFEFB8C8")
    val Purple40 = Color.parseColor("#FF6650a4")
    val PurpleGrey40 = Color.parseColor("#FF625b71")
    val Pink40 = Color.parseColor("#FF7D5260")
}